// local package fixture
<<< "hello from LocalPkg" >>>;
